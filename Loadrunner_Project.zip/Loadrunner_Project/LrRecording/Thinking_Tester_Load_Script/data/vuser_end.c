vuser_end()
{

	/* Logout */

	return 0;
}